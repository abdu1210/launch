import React, { useRef, useEffect } from 'react';

const Tooltip = (props) => {
  let timeout;
  const toolTipRef = useRef<HTMLInputElement>(null);

  const showTip = () => {
    timeout = setTimeout(() => {
      if (toolTipRef.current) toolTipRef.current.style.display = 'block';
    }, props.delay || 400);
  };

  const hideTip = () => {
    clearInterval(timeout);
    if (toolTipRef.current) toolTipRef.current.style.display = 'none';
  };

  useEffect(() => {
    if (props.dynamic && toolTipRef.current) {
      props.status !== 0 && (toolTipRef.current.style.display = 'block');
      timeout = setTimeout(() => {
        if (toolTipRef.current) toolTipRef.current.style.display = 'none';
      }, props.delay || 400);
    }
  }, [props.content]);

  return (
    <div
      className='Tooltip-Wrapper'
      onMouseEnter={showTip}
      onMouseLeave={hideTip}
    >
      {props.children}
      <div className={`Tooltip-Tip ${props.direction || 'top'}`} ref={toolTipRef}>
        {props.content}
      </div>
    </div>
  );
};

export default Tooltip;
