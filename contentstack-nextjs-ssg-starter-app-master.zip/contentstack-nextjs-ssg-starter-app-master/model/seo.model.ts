export interface SEO {
    $: any;
    enable_search_indexing: boolean;
    keywords: string;
    meta_description: string;
    meta_title: string;
}