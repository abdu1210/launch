export interface AllEntries {
    title: string;
    url: string;
    uid: string;
    $: any;
}